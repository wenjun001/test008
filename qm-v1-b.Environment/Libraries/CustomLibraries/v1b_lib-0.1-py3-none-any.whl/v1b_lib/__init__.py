def hello():
    return "v1b_lib from a V1 Environment"
