def hello():
    return "v1a_lib from a V1 Environment"
