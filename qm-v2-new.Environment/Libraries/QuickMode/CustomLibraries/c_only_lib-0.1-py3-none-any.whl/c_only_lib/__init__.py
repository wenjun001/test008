def hello():
    return "c_only_lib from Quick Mode in C"
