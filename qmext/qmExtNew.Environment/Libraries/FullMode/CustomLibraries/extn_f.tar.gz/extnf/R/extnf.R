extnf <- function() 'extn f r v1'
