from setuptools import setup

setup(name='extnup', version='0.1', py_modules=['extnup'])
