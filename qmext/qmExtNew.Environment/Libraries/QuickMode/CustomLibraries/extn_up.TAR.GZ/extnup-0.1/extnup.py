VALUE = 'extn up v1'
