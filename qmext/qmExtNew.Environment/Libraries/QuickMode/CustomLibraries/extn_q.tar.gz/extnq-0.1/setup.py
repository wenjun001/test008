from setuptools import setup

setup(name='extnq', version='0.1', py_modules=['extnq'])
