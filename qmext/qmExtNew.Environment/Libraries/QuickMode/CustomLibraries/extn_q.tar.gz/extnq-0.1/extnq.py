VALUE = 'extn q v1'
