from setuptools import setup

setup(name='extdup', version='0.1', py_modules=['extdup'])
