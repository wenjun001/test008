from setuptools import setup

setup(name='extq', version='0.1', py_modules=['extq'])
