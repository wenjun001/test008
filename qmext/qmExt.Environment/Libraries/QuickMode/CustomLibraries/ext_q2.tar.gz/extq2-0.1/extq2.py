VALUE = 'ext q2 v1'
