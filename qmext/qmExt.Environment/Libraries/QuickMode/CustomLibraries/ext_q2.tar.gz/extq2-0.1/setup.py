from setuptools import setup

setup(name='extq2', version='0.1', py_modules=['extq2'])
