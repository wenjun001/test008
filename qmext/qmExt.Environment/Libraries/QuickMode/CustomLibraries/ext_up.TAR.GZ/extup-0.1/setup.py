from setuptools import setup

setup(name='extup', version='0.1', py_modules=['extup'])
