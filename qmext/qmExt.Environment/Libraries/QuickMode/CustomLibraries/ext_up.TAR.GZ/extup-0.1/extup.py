VALUE = 'ext up v1'
