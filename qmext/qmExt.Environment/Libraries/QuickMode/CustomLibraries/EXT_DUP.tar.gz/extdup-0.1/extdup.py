VALUE = 'ext dup b'
