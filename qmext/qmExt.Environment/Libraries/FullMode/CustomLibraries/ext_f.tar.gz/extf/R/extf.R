extf <- function() 'ext f r v1'
