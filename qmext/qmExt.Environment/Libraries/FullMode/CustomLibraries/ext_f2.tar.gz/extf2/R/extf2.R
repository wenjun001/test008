extf2 <- function() 'ext f2 r v1'
