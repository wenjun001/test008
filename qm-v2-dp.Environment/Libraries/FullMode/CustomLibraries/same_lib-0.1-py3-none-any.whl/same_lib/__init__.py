def hello():
    return "same_lib Full Mode copy"
