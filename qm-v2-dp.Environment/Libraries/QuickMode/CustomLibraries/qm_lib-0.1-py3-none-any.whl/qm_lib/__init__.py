def hello():
    return "qm_lib from Quick Mode"
