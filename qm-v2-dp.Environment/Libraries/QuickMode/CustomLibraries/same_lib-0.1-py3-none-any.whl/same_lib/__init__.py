def hello():
    return "same_lib Quick Mode copy"
