VALUE = 't5c_lib'
