def hello():
    return "qmdemo 0.1.0"
