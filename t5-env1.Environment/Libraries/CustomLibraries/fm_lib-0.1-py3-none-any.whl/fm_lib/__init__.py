def hello():
    return "fm_lib from Full Mode"
